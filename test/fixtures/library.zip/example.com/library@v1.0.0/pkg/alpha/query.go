package alpha
// dependency-alpha-context
func Query() string { return "alpha" }
