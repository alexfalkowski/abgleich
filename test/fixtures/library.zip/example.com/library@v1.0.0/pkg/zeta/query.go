package zeta
// dependency-zeta-context
func Query() string { return "zeta" }
